package centralina;

import shared.IntDirettiva;
import centralina.ValoreParametri;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.*;
public class Centralina extends UnicastRemoteObject implements Runnable, IntDirettiva{
	private static Vector<Thread> lista_thread = new Vector();
	private static Vector<Centralina> lista_centraline = new Vector();
	private static Timer timer = new Timer();
	private ValoreParametri valoreparametri;	
	
	public Centralina(String posizione,String id_centralina,int numero_veicoli_limite,
            int limite_velocit�,int intervallo_di_tempo) throws RemoteException {
		
		  this.valoreparametri =  new ValoreParametri (posizione, id_centralina, numero_veicoli_limite, limite_velocit�, intervallo_di_tempo);
		  
	}
	
	public Centralina() throws RemoteException{
		// TODO Auto-generated constructor stub
	}

	public void setAggiornamento(ValoreParametri nuovivalori) {
		
		this.valoreparametri.aggiornamentoParametri(nuovivalori);
		
	}
	
	
	
	public ValoreParametri getValoriParametri() {
		return this.valoreparametri;
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		rileva();
	}
	
	
	public void rileva() {
		TimerTask task;
		task = new TimerTask() {
			
			@Override
			//estrae valori di velocit�
			public void run() {
				Random estrattore = new Random();
				int n_auto = estrattore.nextInt(valoreparametri.getNumero_veicoli_limite() + (int) (valoreparametri.getNumero_veicoli_limite()*0.4));
				int[] velocita;
				velocita = new int[n_auto];
				for(int i = 0; i < n_auto; ++i) {
					velocita[i] = estrattore.nextInt(valoreparametri.getLimite_velocit�() + (int) (valoreparametri.getLimite_velocit�()*0.25));
				}
				int media = 0;
				
				//calcolo la velocita media
				for(int j=0; j<n_auto; ++j) {
					media = media + velocita[j];
				}
				if(n_auto == 0)
					media = 0;
				else
					media = media/n_auto;
				
				System.out.println(valoreparametri.getPosizione() + ":  \nn_auto: " + n_auto +"\nVelocita: " + media);
				
				
			}
		};
		timer.scheduleAtFixedRate(task, valoreparametri.getIntervallo_di_tempo(), valoreparametri.getIntervallo_di_tempo());
		
		
	}
	
	public void nuovaCentralina(String posizione, String id_centralina, int numero_veicoli_limite,int limite_velocita, int intervallo_di_tempo) throws RemoteException {
		Centralina nuova = new Centralina(posizione, id_centralina, numero_veicoli_limite, limite_velocita, intervallo_di_tempo);
		Thread t = new Thread(nuova);
		lista_thread.addElement(t);
		lista_centraline.addElement(nuova);
		t.start();
	}

	
	public void eliminaCentralina(String id_centralina) {
		for(int i=0; i<lista_centraline.size(); ++i) {
			if(id_centralina.equals(lista_centraline.get(i).getValoriParametri().getId_centralina())) {
				lista_centraline.remove(i);
				lista_thread.remove(i);
				break;
			}
		}
	}
	
}
