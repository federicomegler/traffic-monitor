package centralina;

public class ValoreParametri {
	
	private String posizione;
	private String id_centralina;
	private int numero_veicoli_limite;
	private int limite_velocita;
	private int intervallo_di_tempo;

	public ValoreParametri(String posizione, String id_centralina, int numero_veicoli_limite,
            int limite_velocit�, int intervallo_di_tempo) {
		this.setPosizione(posizione);
		this.setId_centralina(id_centralina);
		this.setNumero_veicoli_limite(numero_veicoli_limite);
		this.setLimite_velocit�(limite_velocit�);
		this.setIntervallo_di_tempo(intervallo_di_tempo);
	}
	
	public void aggiornamentoParametri(ValoreParametri nuovivalori) {
		this.setId_centralina(nuovivalori.getId_centralina());
		this.setIntervallo_di_tempo(nuovivalori.getIntervallo_di_tempo());
		this.setLimite_velocit�(nuovivalori.getLimite_velocit�());
		this.setNumero_veicoli_limite(nuovivalori.getNumero_veicoli_limite());
		this.setPosizione(nuovivalori.getPosizione());
	}
	
	// getter e setter
		public String getPosizione() {
			return posizione;
		}
		public void setPosizione(String posizione) {
			this.posizione = posizione;
		}
		public int getNumero_veicoli_limite() {
			return numero_veicoli_limite;
		}
		public void setNumero_veicoli_limite(int numero_veicoli_limite) {
			this.numero_veicoli_limite = numero_veicoli_limite;
		}
		public int getLimite_velocit�() {
			return limite_velocita;
		}
		public void setLimite_velocit�(int limite_velocit�) {
			this.limite_velocita = limite_velocit�;
		}
		public String getId_centralina() {
			return id_centralina;
		}
		public void setId_centralina(String id_centralina) {
			this.id_centralina = id_centralina;
		}
		public int getIntervallo_di_tempo() {
			return intervallo_di_tempo;
		}
		public void setIntervallo_di_tempo(int intervallo_di_tempo) {
			this.intervallo_di_tempo = intervallo_di_tempo;
		}

}
