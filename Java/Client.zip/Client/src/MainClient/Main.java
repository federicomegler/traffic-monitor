package MainClient;

import utente.*;
import graficaUtente.*;
import shared.IntACC;

import java.net.MalformedURLException;
import java.rmi.*;
import java.rmi.server.*;

import gestoreAccessoSistema.GestoreAccessoSistema;

public class Main {
	private static Utente utente;
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LogIn finestra = new LogIn();
		finestra.setVisible(true);
		
	}
	
	public static Utente getThisUtente() {
		return utente;
	}
	
	
	
	public static String[] ottieniCredenziali(String nickname) throws MalformedURLException, RemoteException, NotBoundException {
		IntACC server = (IntACC)Naming.lookup("rmi://localhost:12345/ACCESSO");
		return server.getCredenziali(nickname);		
	}
	
	public static void setUtente(String nome, String cognome, String nickname, String password, int isAdmin) {
		if(isAdmin == 1) {
			utente = new Admin(nome,cognome,nickname,password,isAdmin);
		}
		else {
			utente = new Utente(nome,cognome,nickname,password,isAdmin);
		}
	}
	
	public static Utente getUtente() {
		return utente;
	}
	
	public static boolean credenzialiValide(String nickname, String password) throws MalformedURLException, RemoteException, NotBoundException {
		IntACC server = (IntACC)Naming.lookup("rmi://localhost:12345/ACCESSO");
		try {
			return server.credValide(nickname, password);
		}
		catch(RemoteException e){
			e.printStackTrace();
			return false;
		}
	}
	
	public static int creaUtente(String nome, String cognome, String nickname, String password, int isAdmin) throws MalformedURLException, RemoteException, NotBoundException {
		IntACC server = (IntACC) Naming.lookup("rmi://localhost:12345/ACCESSO");
		int controllo;
		try {		
			controllo = server.esisteUtente(nickname);
			if(controllo == 1) {
				server.aggiungiUtente(nome, cognome, nickname, password, isAdmin);
			}
		}
		catch(RemoteException e) {
			e.printStackTrace();
			return -1;
		}
		return controllo;
	}
	
	public static boolean modificaPassword(String nickname, String password) throws MalformedURLException, RemoteException, NotBoundException {
		IntACC server = (IntACC) Naming.lookup("rmi://localhost:12345/ACCESSO");
		try {
			server.modificaPassword(nickname, password);
			return true;
		}
		catch(RemoteException e) {
			e.printStackTrace();
			return false;
		}
	}
}
