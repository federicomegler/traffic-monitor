package MainClient;
import graficaUtente.LogIn;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LogIn utente = new LogIn();
	}

}
