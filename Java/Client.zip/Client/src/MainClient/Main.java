package MainClient;

import utente.*;
import graficaUtente.*;
import shared.IntACC;

import java.net.MalformedURLException;
import java.rmi.*;
import java.rmi.server.*;

import gestoreAccessoSistema.GestoreAccessoSistema;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LogIn finestra = new LogIn();
		finestra.setVisible(true);
		
	}
	
	public static int creaUtente(String nome, String cognome, String nickname, String password) throws MalformedURLException, RemoteException, NotBoundException {
		IntACC server = (IntACC) Naming.lookup("rmi://localhost:12345/ACCESSO");
		try {		
			return server.aggiungiUtente(nome, cognome, nickname, password);
		}
		catch(RemoteException e) {
			e.printStackTrace();
			return -1;
		}
	}
}
