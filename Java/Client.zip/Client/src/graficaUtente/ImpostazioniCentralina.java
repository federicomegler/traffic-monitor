package graficaUtente;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import utente.Admin;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import javax.swing.SpinnerListModel;
import java.awt.Toolkit;
import javax.swing.border.BevelBorder;
import java.awt.Dimension;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class ImpostazioniCentralina extends JFrame {

	private JPanel contentPane;
	private JTextField textPosizione;
	private JSpinner limiteVetture;
	private JSpinner limiteVelocita;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ImpostazioniCentralina frame = new ImpostazioniCentralina();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ImpostazioniCentralina() {
		setMaximumSize(new Dimension(700, 300));
		setIconImage(Toolkit.getDefaultToolkit().getImage(ImpostazioniCentralina.class.getResource("/Resources/IconaSemaforo.png")));
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 700, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNuovaCentralina = new JLabel("Nuova centralina:");
		lblNuovaCentralina.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNuovaCentralina.setBounds(10, 11, 130, 30);
		contentPane.add(lblNuovaCentralina);
		
		JLabel lblNomeVia = new JLabel("Nome via:");
		lblNomeVia.setBounds(10, 70, 130, 14);
		contentPane.add(lblNomeVia);
		
		textPosizione = new JTextField();
		textPosizione.setBounds(150, 67, 160, 20);
		contentPane.add(textPosizione);
		textPosizione.setColumns(10);
		
		JLabel lblLimiteVetture = new JLabel("Limite vetture:");
		lblLimiteVetture.setBounds(10, 95, 130, 14);
		contentPane.add(lblLimiteVetture);
		
		JLabel lblLimiteVelocit = new JLabel("Limite velocit\u00E0:");
		lblLimiteVelocit.setBounds(10, 120, 130, 14);
		contentPane.add(lblLimiteVelocit);
		
		limiteVetture = new JSpinner();
		limiteVetture.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(10)));
		limiteVetture.setBounds(150, 92, 80, 20);
		contentPane.add(limiteVetture);
		
		JButton btnCrea = new JButton("Crea");
		btnCrea.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnCrea.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Admin.inviaDirettiva(textPosizione.getText(), Integer.parseInt(limiteVetture.getValue().toString()), 
							             Integer.parseInt(limiteVelocita.getValue().toString()));
				} catch (NumberFormatException | MalformedURLException | RemoteException | NotBoundException e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
		btnCrea.setBounds(150, 148, 89, 23);
		contentPane.add(btnCrea);
		
		JLabel lblVia = new JLabel("via:");
		lblVia.setHorizontalAlignment(SwingConstants.RIGHT);
		lblVia.setBounds(103, 70, 46, 14);
		contentPane.add(lblVia);
		
		limiteVelocita = new JSpinner();
		limiteVelocita.setModel(new SpinnerListModel(new String[] {"30", "50", "90"}));
		limiteVelocita.setBounds(150, 117, 80, 20);
		contentPane.add(limiteVelocita);
		
		JLabel lblKmh = new JLabel("Km/h");
		lblKmh.setBounds(235, 120, 46, 14);
		contentPane.add(lblKmh);
		
		JPanel panel = new JPanel();
		panel.setBorder(new BevelBorder(BevelBorder.LOWERED, null, null, null, null));
		panel.setBounds(350, 11, 324, 239);
		contentPane.add(panel);
		panel.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Modifica centralina:");
		lblNewLabel.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNewLabel.setBounds(10, 11, 180, 30);
		panel.add(lblNewLabel);
		
		JLabel lblIdcentralina = new JLabel("IDcentralina:");
		lblIdcentralina.setBounds(10, 52, 150, 14);
		panel.add(lblIdcentralina);
		
		JLabel lblNuovoLimiteVetture = new JLabel("Nuovo limite vetture:");
		lblNuovoLimiteVetture.setBounds(10, 77, 150, 14);
		panel.add(lblNuovoLimiteVetture);
		
		JLabel lblNuovoLimiteVelocit = new JLabel("Nuovo limite velocit\u00E0:");
		lblNuovoLimiteVelocit.setBounds(10, 102, 150, 14);
		panel.add(lblNuovoLimiteVelocit);
		
		textField = new JTextField();
		textField.setBounds(170, 49, 144, 20);
		panel.add(textField);
		textField.setColumns(10);
		
		JSpinner spinner = new JSpinner();
		spinner.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(10)));
		spinner.setBounds(170, 74, 80, 20);
		panel.add(spinner);
		
		JSpinner spinner_1 = new JSpinner();
		spinner_1.setModel(new SpinnerListModel(new String[] {"30", "50", "90"}));
		spinner_1.setBounds(170, 99, 80, 20);
		panel.add(spinner_1);
		
		JLabel lblKmh_1 = new JLabel("Km/h");
		lblKmh_1.setBounds(251, 102, 46, 14);
		panel.add(lblKmh_1);
		
		JButton btnModifica = new JButton("Modifica");
		btnModifica.setBounds(170, 147, 89, 23);
		panel.add(btnModifica);
	}
}
