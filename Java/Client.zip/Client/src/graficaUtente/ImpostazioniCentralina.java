package graficaUtente;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import utente.Admin;

import javax.swing.JLabel;
import java.awt.Font;
import javax.swing.JList;
import javax.swing.JTextField;
import javax.swing.JComboBox;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JSpinner;
import javax.swing.SpinnerNumberModel;
import javax.swing.JButton;
import javax.swing.SwingConstants;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import javax.swing.SpinnerListModel;

public class ImpostazioniCentralina extends JFrame {

	private JPanel contentPane;
	private JTextField textPosizione;
	private JSpinner limiteVetture;
	private JSpinner limiteVelocita;
	private JSpinner intervalloTempo;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ImpostazioniCentralina frame = new ImpostazioniCentralina();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public ImpostazioniCentralina() {
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNuovaCentralina = new JLabel("Nuova centralina:");
		lblNuovaCentralina.setFont(new Font("Tahoma", Font.PLAIN, 15));
		lblNuovaCentralina.setBounds(10, 11, 130, 30);
		contentPane.add(lblNuovaCentralina);
		
		JLabel lblNomeVia = new JLabel("Nome via:");
		lblNomeVia.setBounds(10, 70, 130, 14);
		contentPane.add(lblNomeVia);
		
		textPosizione = new JTextField();
		textPosizione.setBounds(150, 67, 160, 20);
		contentPane.add(textPosizione);
		textPosizione.setColumns(10);
		
		JLabel lblLimiteVetture = new JLabel("Limite vetture:");
		lblLimiteVetture.setBounds(10, 95, 130, 14);
		contentPane.add(lblLimiteVetture);
		
		JLabel lblLimiteVelocit = new JLabel("Limite velocit\u00E0:");
		lblLimiteVelocit.setBounds(10, 120, 130, 14);
		contentPane.add(lblLimiteVelocit);
		
		JLabel lblIntervalloTempo = new JLabel("Intervallo tempo:");
		lblIntervalloTempo.setBounds(10, 145, 130, 14);
		contentPane.add(lblIntervalloTempo);
		
		limiteVetture = new JSpinner();
		limiteVetture.setModel(new SpinnerNumberModel(new Integer(1), new Integer(1), null, new Integer(10)));
		limiteVetture.setBounds(150, 92, 80, 20);
		contentPane.add(limiteVetture);
		
		JButton btnCrea = new JButton("Crea");
		btnCrea.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				try {
					Admin.inviaDirettiva(textPosizione.getText(), Integer.parseInt(limiteVetture.getValue().toString()), 
							             Integer.parseInt(limiteVelocita.getValue().toString()), 
							             Integer.parseInt(intervalloTempo.getValue().toString()));
				} catch (NumberFormatException | MalformedURLException | RemoteException | NotBoundException e1) {
					e1.printStackTrace();
				}
				dispose();
			}
		});
		btnCrea.setBounds(150, 173, 89, 23);
		contentPane.add(btnCrea);
		
		JLabel lblVia = new JLabel("via:");
		lblVia.setHorizontalAlignment(SwingConstants.RIGHT);
		lblVia.setBounds(103, 70, 46, 14);
		contentPane.add(lblVia);
		
		limiteVelocita = new JSpinner();
		limiteVelocita.setModel(new SpinnerListModel(new String[] {"30", "50", "90"}));
		limiteVelocita.setBounds(150, 117, 80, 20);
		contentPane.add(limiteVelocita);
		
		intervalloTempo = new JSpinner();
		intervalloTempo.setModel(new SpinnerListModel(new String[] {"10", "20", "30"}));
		intervalloTempo.setBounds(150, 142, 80, 20);
		contentPane.add(intervalloTempo);
		
		JLabel lblKmh = new JLabel("Km/h");
		lblKmh.setBounds(235, 120, 46, 14);
		contentPane.add(lblKmh);
		
		JLabel lblMin = new JLabel("min");
		lblMin.setBounds(235, 145, 46, 14);
		contentPane.add(lblMin);
	}
}
