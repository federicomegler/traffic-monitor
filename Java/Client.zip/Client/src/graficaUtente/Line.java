package graficaUtente;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;

public class Line {
	    public String nome;
	    public final int x1;
	    public final int x2;
	    public final int y1;
	    public final int y2;
	    public char stato;
	    boolean selected = false;
	    public Line(String linea) {//1m =0.15px 100m=15px
	    	String[] vector = linea.split("\\,");
	    	String[]coordinate = vector[0].split("\\�");
	    	y1=(int) (Double.parseDouble(coordinate[0])*0.10)+50;
	    	x1=(int) (Double.parseDouble(coordinate[1])*0.10)+50;
	    	coordinate = vector[1].split("\\�");
	    	y2=(int) (Double.parseDouble(coordinate[0])*0.10)+50;
	    	x2=(int) (Double.parseDouble(coordinate[1])*0.10)+50;
	    	stato = vector[2].charAt(0);
	    	nome = new String(vector[3]);
	    }
	    
	    public void paintBack(Graphics g) {
		 	
		 	Graphics2D g2 = (Graphics2D) g;
		 	g2.setStroke(new BasicStroke(16));
			if(!selected)return;
			g.setColor(Color.MAGENTA);
			g2.drawLine(x1,y1,x2,y2);
		 }
	public void paintStatus(Graphics g) {
	 	
	 	Graphics2D g2 = (Graphics2D) g;
	 	g2.setStroke(new BasicStroke(4));
	 	switch (this.stato) {
		case 'I':
			g2.setColor(Color.RED);
			break;
		case 'M':
			g2.setColor(Color.YELLOW);
			break;
		default:
			g2.setColor(Color.GREEN);
			break;
		}
	 	
	 	g2.drawLine(x1,y1,x2,y2);
		
	 }
	public void paintStreet(Graphics g) {
	 	
	 	Graphics2D g2 = (Graphics2D) g;
	 	g2.setStroke(new BasicStroke(10));
		g.setColor(Color.GRAY);
	 	
		g2.drawLine(x1,y1,x2,y2);
		
	 }
	    
	    
	    public void setSelected(boolean l) {
	    	this.selected = l;
	    }
	    
	    public String getNome() {
	    	return this.nome;
	    }
}
