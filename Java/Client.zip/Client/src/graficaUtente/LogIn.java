package graficaUtente;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.JPasswordField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class LogIn extends JFrame {

	private JPanel contentPane;
	private JTextField txtNome;
	private JPasswordField passwordField;
	private JLabel lblPassuordONickname;
	private JButton btnNewButton;
	private JButton btnRegistrati;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					LogIn frame = new LogIn();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public LogIn() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(LogIn.class.getResource("/Resources/IconaSemaforo.png")));
		setMaximumSize(new Dimension(500, 350));
		setMinimumSize(new Dimension(450, 300));
		setTitle("Log In");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblNome = new JLabel("Nickname:");
		lblNome.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNome.setBounds(10, 43, 130, 14);
		contentPane.add(lblNome);
		
		JLabel lblCognome = new JLabel("Password:");
		lblCognome.setHorizontalAlignment(SwingConstants.RIGHT);
		lblCognome.setBounds(10, 68, 130, 14);
		contentPane.add(lblCognome);
		
		txtNome = new JTextField();
		txtNome.setToolTipText("");
		txtNome.setHorizontalAlignment(SwingConstants.LEFT);
		txtNome.setBounds(150, 40, 180, 20);
		contentPane.add(txtNome);
		txtNome.setColumns(10);
		
		passwordField = new JPasswordField();
		passwordField.setBounds(150, 65, 180, 20);
		contentPane.add(passwordField);
		
		btnNewButton = new JButton("Log In");
		btnNewButton.setBounds(190, 109, 89, 23);
		contentPane.add(btnNewButton);
		
		btnRegistrati = new JButton("Registrati");
		btnRegistrati.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				setVisible(false);
				SignUp.main(null);
			}
		});
		btnRegistrati.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			}
		});
		btnRegistrati.setBounds(190, 189, 89, 23);
		contentPane.add(btnRegistrati);
		
		JLabel lblNonHaiUn = new JLabel("Non hai un account?");
		lblNonHaiUn.setBounds(186, 164, 129, 14);
		contentPane.add(lblNonHaiUn);
		
		lblPassuordONickname = new JLabel("Credenziali errate!");
		lblPassuordONickname.setVisible(false);
		lblPassuordONickname.setForeground(Color.RED);
		lblPassuordONickname.setBounds(289, 113, 135, 14);
		contentPane.add(lblPassuordONickname);
		
	}
	
	
}
