package graficaUtente;
import javax.swing.JFrame;
import javax.swing.JPanel;

import MainClient.Main;

import java.awt.Graphics;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class Mappa extends JPanel{
	
	public static void main() throws NotBoundException, IOException {
		Mappa mappa = new Mappa();
		mappa.setLinee(Main.getLinee());
		JFrame jFrame = new JFrame();
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setSize(800, 800);
        jFrame.setVisible(true);
        jFrame.add(mappa);
	}
	
	
	private Set<Line> linee;
	
	public Mappa() {
	}
	
	public void setLinee(Set<String> vettore) {
		Iterator<String> it = vettore.iterator();
		linee = new HashSet<Line>();
		while(it.hasNext()) {
			Line a = new Line(it.next());
			linee.add(a);
		}
		repaint();
	}
	
	@Override
	public void paintComponent(Graphics g) {
		Iterator<Line> i = linee.iterator();
		Line linea;
		while(i.hasNext()) {
			linea = i.next();
			linea.paint(g);
		}		
	}
	
}
