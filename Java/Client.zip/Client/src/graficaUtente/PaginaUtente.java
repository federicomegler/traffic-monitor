package graficaUtente;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import MainClient.Main;

import java.awt.Toolkit;
import javax.swing.JMenuBar;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPopupMenu;
import java.awt.Component;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JProgressBar;
import javax.swing.JLayeredPane;
import javax.swing.JTabbedPane;

public class PaginaUtente extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2374078284307603564L;
	private JPanel contentPane;
	private JMenuItem mntmChiudi;
	private JTextField textField;

	/**
	 * Launch the application.
	 */
	public static void main(boolean type) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					PaginaUtente frame = new PaginaUtente(type);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public PaginaUtente(boolean type) {
		setTitle("Traffic Monitor");
		setIconImage(Toolkit.getDefaultToolkit().getImage(PaginaUtente.class.getResource("/Resources/IconaSemaforo.png")));
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 650, 450);
		
		JMenuBar menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		JMenu mnFunzioni = new JMenu("Funzioni");
		menuBar.add(mnFunzioni);
		
		mntmChiudi = new JMenuItem("Chiudi");
		mntmChiudi.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				dispose();
			}
		});
		
		JMenu mnGestisciCentraline = new JMenu("Gestisci Centraline");
		mnGestisciCentraline.setVisible(type);
		mnFunzioni.add(mnGestisciCentraline);
		
		JMenuItem mntmCrea = new JMenuItem("Crea centralina");
		mntmCrea.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				ImpostazioniCentralina impostazioni = new ImpostazioniCentralina();
				impostazioni.setVisible(true);
			}
		});
		
		mnGestisciCentraline.add(mntmCrea);
		
		JMenuItem mntmRimuovi = new JMenuItem("Rimuovi centralina");
		mnGestisciCentraline.add(mntmRimuovi);
		mnFunzioni.add(mntmChiudi);
		
		JMenu mnAmministratore = new JMenu("Amministratore");
		mnAmministratore.setVisible(type);
		menuBar.add(mnAmministratore);
		
		JMenuItem mntmNuovoAdmin = new JMenuItem("Nuovo admin");
		mntmNuovoAdmin.setEnabled(type);
		mntmNuovoAdmin.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent arg0) {
				SignUp.main(true);
				dispose();
			}
		});
		mnAmministratore.add(mntmNuovoAdmin);
		
		JMenu mnProfilo = new JMenu("Profilo");
		menuBar.add(mnProfilo);
		
		JMenuItem mntmVisualizzaProfilo = new JMenuItem("Visualizza profilo");
		mntmVisualizzaProfilo.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				Profilo.main(Main.getThisUtente());
				dispose();
			}
		});
		mnProfilo.add(mntmVisualizzaProfilo);
		
		JMenuItem mntmEliminaProfilo = new JMenuItem("Elimina profilo");
		mnProfilo.add(mntmEliminaProfilo);
		
		JMenu mnHelp = new JMenu("Help");
		menuBar.add(mnHelp);
		
		JMenuItem mntmAboutTrafficMonitor = new JMenuItem("About Traffic monitor");
		mntmAboutTrafficMonitor.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {
				
			}
		});
		mnHelp.add(mntmAboutTrafficMonitor);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblSelezionareVia = new JLabel("Selezionare via:");
		lblSelezionareVia.setBounds(10, 11, 100, 14);
		contentPane.add(lblSelezionareVia);
		
		textField = new JTextField();
		textField.setBounds(120, 8, 160, 20);
		contentPane.add(textField);
		textField.setColumns(10);
	}
	private static void addPopup(Component component, final JPopupMenu popup) {
		component.addMouseListener(new MouseAdapter() {
			public void mousePressed(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			public void mouseReleased(MouseEvent e) {
				if (e.isPopupTrigger()) {
					showMenu(e);
				}
			}
			private void showMenu(MouseEvent e) {
				popup.show(e.getComponent(), e.getX(), e.getY());
			}
		});
	}
}
