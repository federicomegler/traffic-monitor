package utente;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import shared.IntAggiornamento;
import utente.Utente;

public class Admin extends Utente {
	
	public static void inviaDirettiva(String posizione, int limite_auto, int limite_velocita, int intervallo_di_tempo) throws MalformedURLException, RemoteException, NotBoundException {
		IntAggiornamento direttiva = (IntAggiornamento) Naming.lookup("rmi://localhost:12345/DIRETTIVE");
		try {
			direttiva.creaCentralina(posizione, limite_auto, limite_velocita, intervallo_di_tempo);
		}
		catch(RemoteException e) {
			e.printStackTrace();
		}
	}
}
