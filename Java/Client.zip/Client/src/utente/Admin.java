package utente;

import utente.Utente;

public class Admin extends Utente {
	private String ciao;

}
