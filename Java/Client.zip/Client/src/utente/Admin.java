package utente;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;

import shared.IntAggiornamento;
import utente.Utente;

public class Admin extends Utente {
	
	public Admin(String nome, String cognome, String nickname, String password, int isAdmin) {
		// TODO Auto-generated constructor stub
		super(nome,cognome,nickname,password,isAdmin);
	}

	public static void inviaDirettiva(String posizione, int limite_auto, int limite_velocita) throws MalformedURLException, RemoteException, NotBoundException {
		IntAggiornamento direttiva = (IntAggiornamento) Naming.lookup("rmi://localhost:12345/DIRETTIVE");
		try {
			direttiva.creaCentralina(posizione, posizione, posizione, posizione, limite_auto, limite_velocita);
		}
		catch(RemoteException e) {
			e.printStackTrace();
		}
	}
}
