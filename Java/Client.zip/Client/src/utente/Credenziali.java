package utente;

public class Credenziali {
	private String nome;
	private String cognome;
	private String nickname;
	private String mail;
	private String cod_id;
	private String password;
	
	public Credenziali(String nome, String cognome, String nickname, String mail, String cod_id, String password) {
		this.nome = nome;
		this.cognome = cognome;
		this.nickname = nickname;
		this.mail = mail;
		this. cod_id = cod_id;
		this.password = password;
	}
	
	
	//getter e setter
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}
	
	
	public String getNickname() {
		return nickname;
	}
	public void setNickname(String nickname) {
		this.nickname = nickname;
	}
	
	
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	
	
	public String getCod_id() {
		return cod_id;
	}
	public void setCod_id(String cod_id) {
		this.cod_id = cod_id;
	}
	
	
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
