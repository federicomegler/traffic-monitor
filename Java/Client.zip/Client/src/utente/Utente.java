package utente;

import utente.Credenziali;
import graficaUtente.*;

public class Utente {
	private Credenziali credenziali;
	
	public Utente() {}
	
	public Utente(String nome, String cognome, String nickname, String password, int isAdmin) {
		setCredenziali(new Credenziali(nome, cognome, nickname, password,isAdmin));
	}

	public Credenziali getCredenziali() {
		return credenziali;
	}

	public void setCredenziali(Credenziali credenziali) {
		this.credenziali = credenziali;
	}	
	
}
