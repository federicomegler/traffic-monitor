package utente;

import utente.Credenziali;

public class Utente {
	private Credenziali credenziali;
	
	public Utente() {}
	
	public Utente(String nome, String cognome, String nickname, String mail, String cod_id, String password) {
		setCredenziali(new Credenziali(nome, cognome, nickname, mail, cod_id, password));
	}

	public Credenziali getCredenziali() {
		return credenziali;
	}

	public void setCredenziali(Credenziali credenziali) {
		this.credenziali = credenziali;
	}
	
	
}
