package mappa;
import mappa.Line;
import mappa.mappaProva.InnerPanel;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.BasicStroke;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;

public class Labyrinth extends JPanel {
	
    private final ArrayList<Line> lines = new ArrayList<Line>();


	public void addLine(Strada strada) {
        this.lines.add(new Line(strada));
    }

    public void paintComponent(Graphics g) {
        for(final Line r : lines) {
            r.paint(g);
        }
    }
    
    
    public static void main(String[] args) throws IOException { 
    	Mappa map=new Mappa();
    	map.riempimento();
    	JFrame jFrame = new JFrame();
        jFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame.setSize(900, 900);
        jFrame.setVisible(true);
    	Labyrinth fram=new Labyrinth();
    	jFrame.add(fram);
    	  Nodo  nodo;
		  Strada strada;
		  Iterator<String> inode=map.getNodi().keySet().iterator();
		  Iterator<Strada> istrada;

		  while(inode.hasNext()) {
			  
			  nodo=map.getNodi().get(inode.next());
			  istrada=nodo.getLista().iterator();
			  while(istrada.hasNext()) {
				  strada=istrada.next();
				 fram.addLine(strada); 
				 
			  }
			  
		  }
    	
    }


    
}

