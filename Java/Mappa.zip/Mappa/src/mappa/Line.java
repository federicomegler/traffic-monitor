package mappa;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import mappa.Labyrinth;
public class Line {
    public final int x1;
    public final int x2;
    public final int y1;
    public final int y2;
    public Line(Strada strada) {//1m =0.15px 100m=15px
    	String s[]=strada.getNode1().getCoordinate().split("\\�" );
    	y1=(int) (Double.parseDouble(s[0])*0.15)+100;
    	x1=(int) (Double.parseDouble(s[1])*0.15)+150;
    	s=strada.getNode2().getCoordinate().split("\\�" );
    	y2=(int) (Double.parseDouble(s[0])*0.15)+100;
    	x2=(int) (Double.parseDouble(s[1])*0.15)+150;
       
    }
    public void paint(Graphics g) {
    	g.setColor(Color.GRAY);
    	Graphics2D g2 = (Graphics2D) g;
    	g2.setStroke(new BasicStroke(10));
    	g2.drawLine(this.x1, this.y1, this.x2, this.y2);
    }
}
