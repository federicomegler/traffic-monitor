package mappa;

import java.util.HashSet;
import java.util.Set;

public class Nodo {
    private boolean mark;
	private String coordinate;
	private Set<Strada> lista; 
	
	public Nodo(String coordinate) {
		
		setCoordinate(coordinate);
	   setLista(new HashSet<Strada>());
	   setMark(false);
		
	}

	public boolean equals(Nodo node) {
		
		return(coordinate.equals(node.getCoordinate()));
		
	}

	public String getCoordinate() {
		return coordinate;
	}

	public void setCoordinate(String coordinate) {
		this.coordinate = coordinate;
	}

	public Set<Strada> getLista() {
		return lista;
	}

	public void setLista(Set<Strada> lista) {
		this.lista = lista;
	}

	public boolean isMark() {
		return mark;
	}

	public void setMark(boolean mark) {
		this.mark = mark;
	}
	
}
