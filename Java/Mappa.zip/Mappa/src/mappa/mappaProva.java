package mappa;
import mappa.Mappa;
import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.geom.Line2D;
import java.awt.BasicStroke;
import java.awt.Color;
import java.io.IOException;


public class mappaProva extends JFrame{

public mappaProva(){
super("Mappa");
getContentPane().add(new InnerPanel());
setSize(650, 650);
setVisible(true);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}

class InnerPanel extends JPanel{
public void paintComponent(Graphics g){ 
	//super.paintComponent(g);

g.setColor(Color.GRAY);
Graphics2D g2 = (Graphics2D) g;
int x1=0,x2=0,y1=0,y2=0;
g2.setStroke(new BasicStroke(10));
g2.draw(new Line2D.Float(30+x1,30+y1,30+x2,30+y2));     

}
}

public static void main(String[] args) throws IOException{
	
mappaProva letspaint = new mappaProva();

}


}