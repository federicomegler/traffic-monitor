package creatoreMappa;
import java.math.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set;

import javax.swing.JFrame;
import javax.swing.JPanel;

import java.awt.Component;
import java.awt.Graphics;
import java.io.*;

public class Mappa  { //grafo con hashmap
	
	private HashMap<String,Nodo> nodi; //coordinate perch� sono uniche per ogni incrocio
	
	public Mappa () {
		
		nodi=new HashMap<String,Nodo>();
		
	}
	
	public HashMap<String,Nodo> getNodi(){
		
		return nodi;
	}
	  public void add (Nodo node1, Nodo node2, int distanza, String nomevia) {
		
		  if(!nodi.containsKey(node1.getCoordinate())) 
			  nodi.put(node1.getCoordinate(), node1); 
		  //controllo se � gi� presente la chiave nel caso l'aggiungo nella hashmap  	     
          if(!nodi.containsKey(node2.getCoordinate())) 
        	  nodi.put(node2.getCoordinate(), node2); 
			//creo un nuovo oggetto strada e lo aggiungo alla lista dei nodi  
          Strada tratto=new Strada(node1,node2,nomevia,distanza);
              nodi.get(node1.getCoordinate()).getLista().add(tratto);
              nodi.get(node2.getCoordinate()).getLista().add(tratto);
		  
	  }

	  public void stampa() {
		  Nodo  nodo;
		  Strada strada;
		  Iterator<String> inode=nodi.keySet().iterator();
		  Iterator<Strada> istrada;
 
		  while(inode.hasNext()) {
			  
			  nodo=nodi.get(inode.next());
			  istrada=nodo.getLista().iterator();
			  System.out.println(nodo.getCoordinate()+" collegato a: ");
			  while(istrada.hasNext()) {
				  
				  strada=istrada.next();
				  System.out.println("    "+(strada.getNode2()).getCoordinate()+" "+strada.getVia()
				  +" "+(strada.getNode1()).getCoordinate()+" lunga: "+strada.getLunghezza() +"\n");
			  }
			  
		  }
	  }

	  
	  public String riferimento(String coordinate) {
	String rif=null;
    double latitudinenodo,longitudinenodo,latitudinepos,longitudinepos,distanza_utente=10000;
	Iterator<String> it=nodi.keySet().iterator();	
	String s[]=coordinate.split("\\�" );
	latitudinepos=Double.parseDouble(s[0]);
	longitudinepos=Double.parseDouble(s[1]);
	
	while(it.hasNext()) {
    String temp=it.next();
    
	latitudinenodo=nodi.get( temp ).getY();
	longitudinenodo= nodi.get( temp ).getX();
	//prendo il nodo pi� vicino all'utente come riferimento	
	if((Math.sqrt(   (latitudinenodo-latitudinepos)*(latitudinenodo-latitudinepos)+(longitudinenodo-longitudinepos)*(longitudinenodo-longitudinepos) )) < distanza_utente) 				
			{rif=(nodi.get( temp ).getCoordinate());
	
	        distanza_utente=(Math.sqrt(   (latitudinenodo-latitudinepos)*(latitudinenodo-latitudinepos)+(longitudinenodo-longitudinepos)*(longitudinenodo-longitudinepos) ));

			}
	 }
	
	return rif;
	
}

	  public void action(String coordinate) { 
        
	    String rif=riferimento(coordinate);
		HashMap<String,String> strade =new HashMap<String,String>();
		int distanza=0;
		controllo (strade,distanza,rif) ;
		Iterator<String> i=strade.keySet().iterator();
		String l[];
		while(i.hasNext()) {
			String tep=i.next();
			l= strade.get(tep).split("\\ ");
			System.out.println("traffico in "+tep+" con tipo traffico "+l[0]+" a distanza "+l[1]);
			
		}
				
			}
	 
	  public void segnalazione(String coordinate,String via,char stato) {
		  
		Set<Strada> vie=nodi.get(coordinate).getLista();
		Iterator<Strada> it=vie.iterator(),o;
        Strada tratto;
        o=vie.iterator();
       while(it.hasNext()){
    	   tratto=it.next();
    	   
        System.out.println(tratto.getVia());
    	   
    	   
       }
       Scanner nome_oggetto_scanner=new Scanner (System.in);
        String frase=nome_oggetto_scanner.nextLine();
        while(o.hasNext()){
     	   tratto=o.next();
     	   
     	   if(frase.equals(tratto.getVia())) { tratto.setStato(stato);}
     	   
     	   
        }
      
			
	  }
	  

		
      public void controllo (HashMap<String,String> strade,int distanza,String root) {
    //visito il  nodo 
    	  if(nodi.get(root).isMark() || distanza>1000) return; //condizione di uscita
    	  nodi.get(root).setMark(true); 
    	  //sto visitando il nodo
    	  Iterator<Strada> it=nodi.get(root).getLista().iterator(); //voglio avere la lista delle strade 
    	  
    	 //la itero tutta e vedo com'� la situazione del traffico per ogni via 
    	  while(it.hasNext()) {
           Strada temp=it.next(); 
    		  if(temp.getStato()!='R') { // se la situa � diversa da regolare 
    			
        	  if(!(strade.containsKey(  temp.getVia() ) ))
               		  strade.put( temp.getVia() ,Character.toString(temp.getStato())+" "+Integer.toString(distanza));
        	  
        	  else {
         
        		  String s[]=(strade.get(temp.getVia() )).split("\\ ");
        		  
        		  if( s[0].charAt(0)>temp.getStato() || (Integer.parseInt(s[1]) > distanza &&  s[0].charAt(0)==temp.getStato()) ) {
        		 
        		  strade.replace(temp.getVia(), strade.get(temp.getVia()),
        				  temp.getStato()+" "+Integer.toString(distanza));
        		  	
        		  }
        		 				  
        	  }
        	  
          }
          
          
    		controllo(strade,distanza+(temp.getLunghezza()),temp.getNode1().getCoordinate()); 
          
        	controllo(strade,distanza+(temp.getLunghezza()),temp.getNode2().getCoordinate()); 
                
    	  
    	  } 
    	  
    	  nodi.get(root).setMark(false);
    	 
  
      }
	
      
	  public void riempimento() throws IOException  {
		  
		   FileReader f;
			    f=new FileReader("C:\\Users\\feder\\eclipse-workspace\\Server\\src\\Resources\\prova.txt");
			    BufferedReader b;
			    b=new BufferedReader(f);
			        
		  	    
		  String nomevia,s,coordinate1,coordinate2;
		  int distanza;
			  
			     while(true) {
			      s=b.readLine();
			      if(s==null)
			        break;
			      String [] splits = s.split("\\ ");
			      coordinate1=splits[0];
			      coordinate2=splits[1];
			      
			      nomevia=splits[2].replaceAll("_", " ");
			      distanza=Integer.parseInt(splits[3]);	
			      
			      
			  Nodo nodo1=new Nodo(coordinate1);
			  Nodo nodo2=new Nodo(coordinate2);
			  this.add(nodo1, nodo2, distanza, nomevia);
			      
			    }  
		  b.close();
	  }

}
