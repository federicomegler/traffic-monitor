package creatoreMappa;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class MappaTest {

	@Test
	void testRiferimento() {
		fail("Not yet implemented");
	}

	@Test
	void testAction() {
		fail("Not yet implemented");
	}

}
