package gestoreAccessoDatabase;
import java.rmi.RemoteException;
import java.sql.*;
import java.util.Set;

import gestoreDirettive.GestoreDirettive;

public class GestoreAccessoDatabase {
	
	private static GestoreAccessoDatabase istance = null;
	
	public static GestoreAccessoDatabase getIstance() throws RemoteException{
		if(istance == null) {
			istance = new GestoreAccessoDatabase();
		}
		return istance;
	}
	
	protected GestoreAccessoDatabase() {
		
	}
	
	public boolean modificaPassword(String nickname, String password) {
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/utente?useUnicode=true&useJDBCCompliant"
                                                          + "TimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
                                                            "root","gruppo6");
			Statement statement = conn.createStatement();
			String query = new String("UPDATE utente SET password = '" + password + "' WHERE nickname = '" + nickname + "';");
			statement.executeUpdate(query);
			conn.close();
			return true;
		}
		catch(Exception e) {
			e.printStackTrace();
			return false;
		}
	}
	
	
	//metodi di lettura nel database
	public ResultSet ottieniVie() throws SQLException {
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/utente?useUnicode=true&useJDBCCompliant"
                + "TimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
                  "root","gruppo6");
		Statement statement = conn.createStatement();
		String query = new String("select * from strada");
		ResultSet result = statement.executeQuery(query);
		return result;
	}
	
	public String[] getCredenziali(String nickname) {
		String[] vettore = null;
		try {
			Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/utente?useUnicode=true&useJDBCCompliant"
					                                       + "TimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC",
					                                       "root","gruppo6");
			
			Statement statement = conn.createStatement();
			
			ResultSet res = statement.executeQuery("select * from utente where nickname = '" + nickname + "'");				
			
			while(res.next()) {
				vettore = new String[5];
				vettore[0] = res.getString("nome");
				vettore[1] = res.getString("cognome");
				vettore[2] = res.getString("nickname");
				vettore[3] = res.getString("password");
				vettore[4] = Integer.toString(res.getInt("admin"));
			}
			conn.close();
		}
		catch(Exception e){
			e.printStackTrace();
		}
		return vettore;
	}
	
	public String[] getMappa() {
		String[] vettore = new String[6];
		return vettore;
	}
	
	//metodi di scrittura nel database
	public void salvaDatiCentralina(String id_centralina, String inizio, String fine, int velocita_media, int numero_auto, Date data, char tipo) throws SQLException {
		Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/utente?useUnicode=true&useJDBCCompliant"
                                                     + "TimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC"
                                                     ,"root","gruppo6");
		Statement statement = conn.createStatement();
		String sql = new String("insert into utente values"
				                + " ('" + id_centralina + " ' , ' " + inizio + "','" + fine + "'," + velocita_media + "," 
				                + numero_auto + "," + data + "," + tipo + ")");
		
		statement.executeUpdate(sql);
		conn.close();
		
	}
	
	public void setCredenziali(String nome, String cognome, String nickname, String password, int isAdmin) {
		try {
			Connection connessione = DriverManager.getConnection("jdbc:mysql://localhost/utente?useUnicode=true&useJDBCCompliant"
					                                              + "TimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC"
					                                              ,"root","gruppo6");
			
			Statement statement = connessione.createStatement();
			String sql = new String("insert into utente (nome, cognome, nickname, password, admin) values"
					+ " ('" + nome + " ' , ' " + cognome + "','" + nickname + "','" + password + "'," + Integer.toString(isAdmin) + ")");
			
			statement.executeUpdate(sql);
			connessione.close();
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	//controllo se un nickname esiste gi�
	public int controlloNick(String nickname) {
		//boolean ritorno = false;
		
		try {
			Connection connessione = DriverManager.getConnection("jdbc:mysql://localhost/utente?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC","root","gruppo6");
			Statement statement = connessione.createStatement();
			String query = new String("select nickname from utente where nickname = '" + nickname +"'");
			ResultSet risultato = statement.executeQuery(query);
			
			
			if(risultato.getRow() == 0) {
				connessione.close();
				return 1;
			}
			else { 
				connessione.close();
				return 0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return -1;
		}
	}
}
