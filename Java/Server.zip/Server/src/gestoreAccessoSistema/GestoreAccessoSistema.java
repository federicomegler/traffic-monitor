package gestoreAccessoSistema;

import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import gestoreAccessoDatabase.GestoreAccessoDatabase;
import gestoreDirettive.GestoreDirettive;
import shared.IntACC;
import shared.IntDirettiva;

public class GestoreAccessoSistema extends UnicastRemoteObject implements IntACC{
	private static GestoreAccessoSistema istance = null;
	
	public static GestoreAccessoSistema getIstance() throws RemoteException{
		if(istance == null) {
			istance = new GestoreAccessoSistema();
		}
		return istance;
	}
	
	protected GestoreAccessoSistema() throws RemoteException {
		super();
	}

	@Override
	public int aggiungiUtente(String nome, String cognome, String nickname, String password) throws RemoteException {
		// TODO Auto-generated method stub
		return GestoreAccessoDatabase.getIstance().setCredenziali(nome, cognome, nickname, password);
	}
}
