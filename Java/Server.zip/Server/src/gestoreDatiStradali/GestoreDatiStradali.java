package gestoreDatiStradali;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.sql.Date;
import java.sql.SQLException;

import gestoreAccessoDatabase.GestoreAccessoDatabase;
import shared.IntCentralina;

public class GestoreDatiStradali extends UnicastRemoteObject implements IntCentralina {
	private static GestoreDatiStradali istance = null;
	
	protected GestoreDatiStradali() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public static GestoreDatiStradali getIstance() throws RemoteException {
		if(istance == null) {
			istance = new GestoreDatiStradali();
		}
		return istance;
	}

	@Override
	public void salvaDatiStradali(String id_centralina, String inizio, String fine, int velocita_media, int n_veicoli)
			throws RemoteException {
		// TODO Auto-generated method stub
		java.util.Date data_oggi = new java.util.Date();
		Date data = new Date(data_oggi.getTime());
		char tipo = computaTraffico(n_veicoli, velocita_media);
		try {
			GestoreAccessoDatabase.getIstance().salvaDatiCentralina(id_centralina, inizio, fine, velocita_media, n_veicoli, data,
																	tipo);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public char computaTraffico(int veicoli_rilev, int vel_rilev) {
		
		int limite_velocita = 50;
		int n_limite_veicoli = 100;
		
		//controllo tipo intenso
		if(n_limite_veicoli/2 < veicoli_rilev) {
			if(limite_velocita/2 > vel_rilev) {
				return 'I';
			}
			else if(limite_velocita*0.8 > vel_rilev) {
				return 'M';
			}
		}
		return 'R';
	}
}
