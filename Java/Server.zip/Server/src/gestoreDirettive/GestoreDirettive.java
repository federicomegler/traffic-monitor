package gestoreDirettive;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import shared.IntAggiornamento;
import shared.IntDirettiva;

public class GestoreDirettive extends UnicastRemoteObject implements IntAggiornamento {
	
	private static GestoreDirettive istance = null;
	
	public static GestoreDirettive getIstance() throws RemoteException{
		if(istance == null) {
			istance = new GestoreDirettive();
		}
		return istance;
	}
	
	protected GestoreDirettive() throws RemoteException {
		super();
		// TODO Auto-generated constructor stub
	}

	public void creaCentralina(String posizione, int n_auto_limite, int velocita_limite) throws MalformedURLException, RemoteException, NotBoundException {
		IntDirettiva server = (IntDirettiva) Naming.lookup("rmi://localhost:1234/CENTRALINA");
		try {
			
			server.nuovaCentralina(posizione,"ciaoid",n_auto_limite,velocita_limite);
		}
		catch(RemoteException e) {
			e.printStackTrace();
		}
	}
	
	public void eliminaCEntralina(String id_centralina) throws MalformedURLException, RemoteException, NotBoundException{
		IntDirettiva server = (IntDirettiva) Naming.lookup("rmi://localhost:1234/CENTRALINA");
		try {		
			server.eliminaCentralina(id_centralina);
		}
		catch(RemoteException e) {
			e.printStackTrace();
		}
	}

	
	
}
