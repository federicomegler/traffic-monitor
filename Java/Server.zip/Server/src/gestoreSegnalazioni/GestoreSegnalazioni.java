package gestoreSegnalazioni;

public class GestoreSegnalazioni {

}
