package gestoreSegnalazioni;

import java.rmi.RemoteException;

public class GestoreSegnalazioni {
	private static GestoreSegnalazioni istance = null;
	
	public static GestoreSegnalazioni getIstance() {
		if(istance == null) {
			istance = new GestoreSegnalazioni();
		}
		return istance;
	}
	
	public boolean inviaSegnalazione(char tipo_traffico, String posizione) throws RemoteException{
		//inserisci stato nel grafo
		return true;
	}
}