package mainClasses;

import java.net.MalformedURLException;
import java.rmi.Naming;
import java.rmi.RMISecurityManager;
import java.rmi.RemoteException;

import sistema.GestoreAccessoSistema;

public class MainSistema {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		try {
			
			System.setSecurityManager(new RMISecurityManager());
			//set the security manager
			
			//create a local instance of the object
			GestoreAccessoSistema Server= new GestoreAccessoSistema();
			
			//put the local instance in the registry
			Naming.rebind("GESTORE-ACCESSO", Server);
			
			System.out.println("Server waiting....");
		}
		catch (MalformedURLException me) {
			System.out.println("Malformed URL:" + me.toString());}
		catch (RemoteException re) {
			System.out.println("Remote expection:" + re.toString()); }
		}
	
			
	}

