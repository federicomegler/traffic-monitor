package sistema;

public class CreatoreStatistiche {

}
