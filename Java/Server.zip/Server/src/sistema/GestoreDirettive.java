package sistema;

public class GestoreDirettive {

}
