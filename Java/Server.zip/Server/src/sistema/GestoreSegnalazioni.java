package sistema;

public class GestoreSegnalazioni {

}
