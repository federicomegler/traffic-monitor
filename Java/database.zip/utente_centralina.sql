-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: utente
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `centralina`
--

LOCK TABLES `centralina` WRITE;
/*!40000 ALTER TABLE `centralina` DISABLE KEYS */;
INSERT INTO `centralina` VALUES (0,'0£0','500£0',50,70,'via mazzini '),(1,'500£0','1000£0',50,70,'via mazzini '),(2,'1000£0','1300£0',50,40,'via mazzini '),(3,'1300£0','1500£0',50,30,'via mazzini '),(4,'1500£0','2000£0',50,70,'via mazzini '),(5,'3000£0','3500£0',50,70,'via angaroni '),(6,'3500£0','4000£0',50,70,'via angaroni '),(7,'500£0','500£300',50,40,'via como '),(8,'500£300','500£500',50,30,'via como '),(9,'500£500','500£1500',50,140,'via como '),(10,'1300£0','1300£500',50,70,'via valleggio '),(11,'1300£500','1300£1000',50,70,'via valleggio '),(12,'1300£1000','1300£1500',50,70,'via valleggio '),(13,'1500£0','1500£500',50,70,'via anzani '),(14,'2000£0','2000£300',50,40,'via pascoli '),(15,'2000£300','2000£500',50,30,'via pascoli '),(16,'2000£500','2000£1000',50,70,'via pascoli '),(17,'0£0','500£500',50,100,'via foscolo '),(18,'1000£0','500£300',30,35,'via manzoni '),(19,'500£500','1300£500',50,110,'via roma '),(20,'1300£500','1500£500',50,30,'via roma '),(21,'1500£500','2000£500',50,70,'via roma '),(22,'1300£1000','1500£1000',90,60,'via leopardi '),(23,'1500£1000','2000£1000',90,140,'via leopardi '),(24,'2000£1000','2200£1000',90,60,'via leopardi '),(25,'2200£1000','2500£1000',90,80,'via leopardi '),(26,'2500£1000','3000£1000',90,140,'via leopardi '),(27,'3000£1000','3500£1000',90,140,'via leopardi '),(28,'3500£1000','4000£1000',90,140,'via leopardi '),(29,'500£1500','1300£1500',90,210,'via ungaretti '),(30,'1300£1500','1500£1500',90,60,'via ungaretti '),(31,'1500£1500','2200£1500',90,190,'via ungaretti '),(32,'2200£1500','2500£1500',90,80,'via ungaretti '),(33,'2500£1500','3000£1500',90,140,'via ungaretti '),(34,'3000£1500','3500£1500',90,140,'via ungaretti '),(35,'3500£1500','4000£1500',90,140,'via ungaretti '),(36,'2000£300','2200£500',50,50,'via alighieri '),(37,'2200£500','2500£1000',50,50,'via alighieri '),(38,'2500£1000','2500£1500',50,70,'via alighieri '),(39,'3000£0','3000£1000',50,140,'via boccaccio '),(40,'3000£1000','3000£1500',50,70,'via boccaccio '),(41,'3500£0','3500£1000',90,280,'via magenta '),(42,'3500£1000','3500£1500',90,140,'via magenta '),(43,'3500£1500','3500£2000',90,140,'via magenta '),(44,'3500£2000','3500£3000',90,280,'via magenta '),(45,'3500£3000','3500£4000',90,280,'via magenta '),(46,'4000£0','4000£1000',90,280,'via petrarca '),(47,'4000£1000','4000£1500',90,140,'via petrarca '),(48,'4000£1500','4000£2000',90,140,'via petrarca '),(49,'4000£2000','4000£3000',90,280,'via petrarca '),(50,'4000£3000','4000£4000',90,180,'via petrarca '),(51,'4000£4000','3500£4000',90,140,'via petrarca '),(52,'2200£500','2200£1000',50,70,'via michelangelo '),(53,'2200£1000','2200£1500',50,70,'via michelangelo '),(54,'1500£1000','1500£1500',50,70,'via raffaello '),(55,'1500£1500','1500£2000',50,70,'via raffaello '),(56,'1500£2000','1500£2500',50,70,'via raffaello '),(57,'500£2000','1500£2000',50,140,'via donatello '),(58,'1500£2000','2200£2000',50,100,'via donatello '),(59,'500£2000','500£2500',50,70,'via leonardo '),(60,'500£2500','500£3000',50,70,'via leonardo '),(61,'500£3000','500£4000',50,140,'via leonardo '),(62,'2200£2000','2200£2500',50,70,'via saba '),(63,'2200£2500','2200£3000',50,70,'via saba '),(64,'2200£3000','2200£4000',50,140,'via saba '),(65,'500£4000','2200£4000',70,360,'via montale '),(66,'500£2500','1300£2500',50,120,'via merini '),(67,'1300£2500','1500£2500',50,30,'via merini '),(68,'1500£2500','2000£2500',50,70,'via merini '),(69,'2000£2500','2200£2500',50,30,'via merini '),(70,'500£3000','1300£3000',90,260,'via ariosto '),(71,'1300£3000','2000£3000',90,250,'via ariosto '),(72,'2000£3000','2200£3000',90,60,'via ariosto '),(73,'2200£3000','3500£3000',90,340,'via ariosto '),(74,'3500£3000','3750£3000',90,70,'via ariosto '),(75,'3750£3000','4000£3000',90,70,'via ariosto '),(76,'1300£2500','1300£3000',50,70,'via marconi '),(77,'1300£3000','1300£3500',50,70,'via marconi '),(78,'1300£3500','2000£3500',50,120,'via marconi '),(79,'2000£3500','2000£3000',50,70,'via marconi '),(80,'2000£3000','2000£2500',50,70,'via marconi '),(81,'3500£2000','3750£2000',50,40,'via garibaldi '),(82,'3750£2000','4000£2000',50,40,'via garibaldi ');
/*!40000 ALTER TABLE `centralina` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-15 19:05:19
