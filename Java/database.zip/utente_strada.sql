-- MySQL dump 10.13  Distrib 8.0.13, for Win64 (x86_64)
--
-- Host: localhost    Database: utente
-- ------------------------------------------------------
-- Server version	8.0.13

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `strada`
--

LOCK TABLES `strada` WRITE;
/*!40000 ALTER TABLE `strada` DISABLE KEYS */;
INSERT INTO `strada` VALUES ('0£0','500£0','via mazzini',500,0),('0£0','500£500','via foscolo',710,17),('1000£0','1300£0','via mazzini',300,2),('1000£0','500£300','via manzoni',580,18),('1300£0','1300£500','via valleggio',500,10),('1300£0','1500£0','via mazzini',200,3),('1300£1000','1300£1500','via valleggio',500,12),('1300£1000','1500£1000','via leopardi',200,22),('1300£1500','1500£1500','via ungaretti',200,30),('1300£2500','1300£3000','via marconi',500,76),('1300£2500','1500£2500','via merini',200,67),('1300£3000','1300£3500','via marconi',500,77),('1300£3000','2000£3000','via ariosto',700,71),('1300£3500','2000£3500','via marconi',700,78),('1300£500','1300£1000','via valleggio',500,11),('1300£500','1500£500','via roma',200,20),('1500£0','1500£500','via anzani',500,13),('1500£0','2000£0','via mazzini',500,4),('1500£1000','1500£1500','via raffaello',500,54),('1500£1000','2000£1000','via leopardi',500,23),('1500£1500','1500£2000','via raffaello',500,55),('1500£1500','2200£1500','via ungaretti',700,31),('1500£2000','1500£2500','via raffaello',500,56),('1500£2000','2200£2000','via donatello',700,58),('1500£2500','2000£2500','via merini',500,68),('1500£500','2000£500','via roma',500,21),('2000£0','2000£300','via pascoli',300,14),('2000£1000','2200£1000','via leopardi',200,24),('2000£2500','2200£2500','via merini',200,69),('2000£300','2000£500','via pascoli',200,15),('2000£300','2200£500','via alighieri',430,36),('2000£3000','2000£2500','via marconi',500,80),('2000£3000','2200£3000','via ariosto',200,72),('2000£3500','2000£3000','via marconi',500,79),('2000£500','2000£1000','via pascoli',500,16),('2200£1000','2200£1500','via michelangelo',500,53),('2200£1000','2500£1000','via leopardi',300,25),('2200£1500','2500£1500','via ungaretti',300,32),('2200£2000','2200£2500','via saba',500,62),('2200£2500','2200£3000','via saba',500,63),('2200£3000','2200£4000','via saba',1000,64),('2200£3000','3500£3000','via ariosto',1300,73),('2200£500','2200£1000','via michelangelo',500,52),('2200£500','2500£1000','via alighieri',430,37),('2500£1000','2500£1500','via alighieri',500,38),('2500£1000','3000£1000','via leopardi',500,26),('2500£1500','3000£1500','via ungaretti',500,33),('3000£0','3000£1000','via boccaccio',1000,39),('3000£0','3500£0','via angaroni',500,5),('3000£1000','3000£1500','via boccaccio',500,40),('3000£1000','3500£1000','via leopardi',500,27),('3000£1500','3500£1500','via ungaretti',500,34),('3500£0','3500£1000','via magenta',1000,41),('3500£0','4000£0','via angaroni',500,6),('3500£1000','3500£1500','via magenta',500,42),('3500£1000','4000£1000','via leopardi',500,28),('3500£1500','3500£2000','via magenta',500,43),('3500£1500','4000£1500','via ungaretti',500,35),('3500£2000','3500£3000','via magenta',1000,44),('3500£2000','3750£2000','via garibaldi',250,81),('3500£3000','3500£4000','via magenta',1000,45),('3500£3000','3750£3000','via ariosto',250,74),('3750£2000','3750£3000','via verdi',1000,NULL),('3750£2000','4000£2000','via garibaldi',250,82),('3750£3000','4000£3000','via ariosto',250,75),('4000£0','4000£1000','via petrarca',1000,46),('4000£1000','4000£1500','via petrarca',500,47),('4000£1500','4000£2000','via petrarca',500,48),('4000£2000','4000£3000','via petrarca',1000,49),('4000£3000','4000£4000','via petrarca',1000,50),('4000£4000','3500£4000','via petrarca',500,51),('500£0','1000£0','via mazzini',500,1),('500£0','500£300','via como',300,7),('500£1500','1300£1500','via ungaretti',800,29),('500£2000','1500£2000','via donatello',1000,57),('500£2000','500£2500','via leonardo',500,59),('500£2500','1300£2500','via merini',800,66),('500£2500','500£3000','via leonardo',500,60),('500£300','500£500','via como',200,8),('500£3000','1300£3000','via ariosto',800,70),('500£3000','500£4000','via leonardo',1000,61),('500£4000','2200£4000','via montale',1700,65),('500£500','1300£500','via roma',800,19),('500£500','500£1500','via como',1000,9);
/*!40000 ALTER TABLE `strada` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2018-12-15 19:05:20
