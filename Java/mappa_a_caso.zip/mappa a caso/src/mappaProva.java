import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.Graphics;
import java.awt.Color;

public class mappaProva extends JFrame{

public mappaProva(){
super("Mappa");
getContentPane().add(new InnerPanel());
setSize(650, 650);
setVisible(true);
setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
}

class InnerPanel extends JPanel{
public void paintComponent(Graphics g){ 
	super.paintComponent(g);
	 Color pippo;
	 pippo = Color.BLACK;

g.setColor(Color.GRAY);     //via mazzini 
g.fillRect(25, 25, 5, 75);   //prima � di x, seconda � y, terza � larghezza, quarta � altezza//
g.setColor(Color.BLUE);
g.fillRect(25, 100, 5, 75);
g.setColor(Color.GRAY);
g.fillRect(25, 175, 5, 45); //tratto da 300
g.setColor(Color.GRAY);
g.fillRect(25, 220, 5, 30); //tratto da 200
g.setColor(Color.GRAY);
g.fillRect(25, 250, 5, 75);

g.setColor (Color.GRAY);      //via angaroni
g. fillRect(25, 475, 5, 75);
g.setColor (Color.GRAY);
g. fillRect(25, 550, 5, 75);

g.setColor (Color.RED);   //via como
g. fillRect(30, 100, 45, 5);
g.setColor (Color.YELLOW);   
g. fillRect(75, 100, 30, 5);
g.setColor (Color.RED);   
g. fillRect(105, 100, 75, 5);
g.setColor (Color.RED);   
g. fillRect(180, 100, 75, 5);


}
}

public static void main(String[] args){
mappaProva letspaint = new mappaProva();
}

}