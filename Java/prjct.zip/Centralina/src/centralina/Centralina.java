package centralina;
import centralina.ValoreParametri;
public class Centralina {

	private ValoreParametri valoreparametri;
	public Centralina(String posizione,char id_centralina[],int numero_veicoli_limite,
            int limite_velocit�,int intervallo_di_tempo) {
		
		  this.valoreparametri =  new ValoreParametri (posizione, id_centralina,numero_veicoli_limite,limite_velocit�,intervallo_di_tempo);
		  
	}
	public void setAggiornamento(ValoreParametri nuovivalori) {
		
		this.valoreparametri.aggiornamentoParametri(nuovivalori);
		
	}
	public ValoreParametri getValoriParametri() {
		
		return this.valoreparametri;
		
	}
		
}
