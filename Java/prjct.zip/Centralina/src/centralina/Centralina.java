package centralina;

import java.util.Timer;

import centralina.ValoreParametri;
import java.util.*;
import java.util.TimerTask;
public class Centralina implements Runnable{
	private static Timer timer = new Timer();
	private ValoreParametri valoreparametri;	
	
	public Centralina(String posizione,String id_centralina,int numero_veicoli_limite,
            int limite_velocit�,int intervallo_di_tempo) {
		
		  this.valoreparametri =  new ValoreParametri (posizione, id_centralina, numero_veicoli_limite, limite_velocit�, intervallo_di_tempo);
		  
	}
	
	public void setAggiornamento(ValoreParametri nuovivalori) {
		
		this.valoreparametri.aggiornamentoParametri(nuovivalori);
		
	}
	
	
	
	public ValoreParametri getValoriParametri() {
		return this.valoreparametri;
	}
	
	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		rileva();
	}
	
	
	public void rileva() {
		TimerTask task;
		task = new TimerTask() {
			
			@Override
			//estrae valori di velocit�
			public void run() {
				Random estrattore = new Random();
				int n_auto = estrattore.nextInt(valoreparametri.getNumero_veicoli_limite() + (int) (valoreparametri.getNumero_veicoli_limite()*0.4));
				int[] velocita;
				velocita = new int[n_auto];
				for(int i = 0; i < n_auto; ++i) {
					velocita[i] = estrattore.nextInt(valoreparametri.getLimite_velocit�() + (int) (valoreparametri.getLimite_velocit�()*0.25));
				}
				int media = 0;
				
				//calcolo la velocita media
				for(int j=0; j<n_auto; ++j) {
					media = media + velocita[j];
				}
				if(n_auto == 0)
					media = 0;
				else
					media = media/n_auto;
				
				System.out.println(valoreparametri.getPosizione() + ":  \nn_auto: " + n_auto +"\nVelocita: " + media);
				
				
			}
		};
		timer.scheduleAtFixedRate(task, valoreparametri.getIntervallo_di_tempo()*60*1000, valoreparametri.getIntervallo_di_tempo()*60*1000);
		
		
	}
	
}
