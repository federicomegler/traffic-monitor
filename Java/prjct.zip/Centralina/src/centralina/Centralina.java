package centralina;
import centralina.ValoreParametri;
public class Centralina {

	private ValoreParametri valoreparametri;
	public Centralina() {}
	public void setAggiornamento(ValoreParametri nuovivalori) {
		
		this.valoreparametri.aggiornamentoParametri(nuovivalori);
		
	}
	public void getValoriParametri() {
		
		
		
	}
		
}
