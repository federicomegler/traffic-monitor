package mainCentralina;

import centralina.Centralina;


public class MainCentralina {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Centralina a = new Centralina("via roma", "A1B5N3K5G7M4", 300, 90, 30);
		Centralina b = new Centralina("via torino", "A1B5N3K5G7M3", 100, 50, 30);
		Centralina c = new Centralina("via milano", "A1B5N3K5G7M2", 500, 90, 30);
		Centralina d = new Centralina("via napoli", "A1B5N3K5G7M1", 55, 30, 30);
		Centralina e = new Centralina("via mazzoleni", "A1B5N3K5G7L9", 80, 50, 30);
		Centralina f = new Centralina("via pescyolinodemmerda", "A1B5N3K5G7L8", 200, 90, 30);
		Centralina g = new Centralina("via catanzaro", "A1B5N3K5G7L7", 250, 50, 30);
		Centralina h = new Centralina("via bari vecchia", "A1B5N3K5G7L6", 140, 50, 30);
		Centralina i = new Centralina("via genova", "A1B5N3K5G7L5", 350, 90, 30);
		Centralina j = new Centralina("via tripoli", "A1B5N3K5G7L4", 40, 30, 30);
		Thread aa = new Thread(a);
		Thread bb = new Thread(b);
		Thread cc = new Thread(c);
		Thread dd = new Thread(d);
		Thread ee = new Thread(e);
		Thread ff = new Thread(f);
		Thread gg = new Thread(g);
		Thread hh = new Thread(h);
		Thread ii = new Thread(i);
		Thread jj = new Thread(j);
		aa.start();
		bb.start();
		cc.start();
		dd.start();
		ee.start();
		ff.start();
		gg.start();
		hh.start();
		ii.start();
		jj.start();
	}
	
}

