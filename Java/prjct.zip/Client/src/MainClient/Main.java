package MainClient;

import utente.*;
import graficaUtente.*;
import shared.IntACC;
import sistema.GestoreAccessoSistema;

import java.rmi.*;
import java.rmi.server.*;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LogIn finestra = new LogIn();
		finestra.setVisible(true);
		
		 
		// set the security manager for the client System.setSecurityManager(new RMISecurityManager()); //get the remote object from the registry
		try
		{
			System.out.println("Security Manager loaded");
			String url = "//localhost/GESTORE-ACCESSO";
			GestoreAccessoSistema remoteObject = (GestoreAccessoSistema)Naming.lookup(url); System.out.println("Got remote object");
			System.out.println(remoteObject.invia());
		}
		catch (RemoteException exc) {
			System.out.println("Error in lookup: " + exc.toString()); } catch (java.net.MalformedURLException exc) {
				System.out.println("Malformed URL: " + exc.toString()); } catch (java.rmi.NotBoundException exc) {
					System.out.println("NotBound: " + exc.toString());

				}
	}
}
