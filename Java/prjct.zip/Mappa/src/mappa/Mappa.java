package mappa;
import java.math.*;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import mappa.Nodo;
import mappa.Strada;
import java.io.*;

public class Mappa {
	private HashMap<String,Nodo> nodi; //coordinate perch� sono uniche per ogni incrocio
	
	public Mappa () {
		
		nodi=new HashMap<String,Nodo>();
		
	}
	
	  public void add (Nodo node1, Nodo node2, int distanza, String nomevia) {
		
		  if(!nodi.containsKey(node1.getCoordinate())) 
			  nodi.put(node1.getCoordinate(), node1); 
		  //controllo se � gi� presente la chiave nel caso l'aggiungo nella hashmap  	     
          if(!nodi.containsKey(node2.getCoordinate())) 
        	  nodi.put(node2.getCoordinate(), node2); 
			//creo un nuovo oggetto strada e lo aggiungo alla lista dei nodi  
          Strada tratto=new Strada(node1,node2,nomevia,distanza);
              nodi.get(node1.getCoordinate()).getLista().add(tratto);
              nodi.get(node2.getCoordinate()).getLista().add(tratto);
		  
	  }

	  public void stampa() {
		  Nodo  nodo;
		  Strada strada;
		  Iterator inode=nodi.keySet().iterator();
		  Iterator istrada;
 
		  while(inode.hasNext()) {
			  
			  nodo=nodi.get((String)inode.next());
			  istrada=nodo.getLista().iterator();
			  System.out.println(nodo.getCoordinate()+" collegato a: ");
			  while(istrada.hasNext()) {
				  
				  strada=(Strada) istrada.next();
				  System.out.println("    "+(strada.getNode2()).getCoordinate()+" "+strada.getVia()
				  +" "+(strada.getNode1()).getCoordinate()+" lunga: "+strada.getLunghezza() +"\n");
			  }
			  
		  }
	  }

		public void action(String coordinate) { // 500 m circa 0,005 di differenza 

		Iterator it=nodi.keySet().iterator();
		Set<Nodo> target= new HashSet<Nodo>();	
		double latitudinenodo,longitudinenodo,latitudinepos,longitudinepos;
		String s[]=coordinate.split("\\ �" );
		latitudinepos=Double.parseDouble(s[0]);
		longitudinepos=Double.parseDouble(s[1]);
		while(it.hasNext()) {
	    s=nodi.get( it.next() ).getCoordinate().split("\\ �");
		latitudinenodo=	Double.parseDouble( s[0] );
		longitudinenodo= Double.parseDouble( s[1] );
		//se il nodo sta nel mio raggio di azione lo metto nel target	
		if(Math.sqrt(   (latitudinenodo-latitudinepos)*(latitudinenodo-latitudinepos)+
		      (longitudinenodo-longitudinepos)*(longitudinenodo-longitudinepos) ) <= 0.0055) 				
				target.add(nodi.get( it.next() ));	
		 }
    //adesso controllo lo stato delle vie dei nodi interessati in caso di traffico faccio notifica
		it=target.iterator();
		//dichiaro il set delle vie in questo set metto dentro le vie con 
		//lo stato diverso da regolare e poi creo notifica
		Iterator istrada;
		while(it.hasNext()) {
			
		//istrada=(it.next());	
			
		}
				
			}
	  
	  public void riempimento() throws IOException  {
		  
		   FileReader f;
			    f=new FileReader("C:\\Users\\Angelo Paone\\Desktop\\prova.txt");
			    BufferedReader b;
			    b=new BufferedReader(f);
			        
			    
		  String coordinate1,coordinate2,nomevia,s;
		  int distanza;
			  
			     while(true) {
			      s=b.readLine();
			      if(s==null)
			        break;
			      String [] splits = s.split("\\ ");
			      coordinate1=splits[0];
			      coordinate2=splits[1];
			      nomevia=splits[2].replaceAll("_", " ");
			      distanza=Integer.parseInt(splits[3]);			    
			  Nodo nodo1=new Nodo(coordinate1);
			  Nodo nodo2=new Nodo(coordinate2);
			  this.add(nodo1, nodo2, distanza, nomevia);
			      
			    }  
		  
	  }
	  
	  public static void main(String[] args) throws IOException {
		 
		 Mappa mappa=new Mappa();
         mappa.riempimento();
		 mappa.stampa();
		  }

}
