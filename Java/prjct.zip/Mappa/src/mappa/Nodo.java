package mappa;

import java.util.HashSet;
import java.util.Set;

public class Nodo {

	private String coordinate;
	private Set<Strada> lista; 
	
	public Nodo(String coordinate) {
		
		setCoordinate(coordinate);
	   setLista(new HashSet<Strada>());
		
	}

	public boolean equals(Nodo node) {
		
		return(coordinate.equals(node.getCoordinate()));
		
	}
	
//	public boolean action(String lat,String lon) {
//		
//		//implementare la funzione che converte string a double e
//		//poi fare il modulo della pos del tizio - pos nodo e vedere se � < del raggio di azione 
//		 return true;
//		
//	}

	public String getCoordinate() {
		return coordinate;
	}

	public void setCoordinate(String coordinate) {
		this.coordinate = coordinate;
	}

	public Set<Strada> getLista() {
		return lista;
	}

	public void setLista(Set<Strada> lista) {
		this.lista = lista;
	}
	
}
