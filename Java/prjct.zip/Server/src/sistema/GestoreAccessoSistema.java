package sistema;

import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

import shared.IntACC;

public class GestoreAccessoSistema extends UnicastRemoteObject implements IntACC{
	
	public GestoreAccessoSistema() throws RemoteException {
		super();
	}

	//private static final long serialVersionUID = 7787401541047824619L;
	
	public String[] invia() {
		String[] dati = new String[6];
		for(int i=0; i<6; ++i) {
			if(i == 0)
				dati[i] = "false";
			else
				dati[i] = "";
		}
		
		return dati; 
	}
}
