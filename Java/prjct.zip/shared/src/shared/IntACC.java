package shared;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IntACC extends Remote{
	public String[] invia() throws RemoteException;
}
