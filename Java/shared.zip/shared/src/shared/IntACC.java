package shared;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IntACC extends Remote{
	public int aggiungiUtente(String nome, String cognome, String nickname, String password) throws RemoteException;
}
