package shared;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IntAggiornamento extends Remote{
	public void creaCentralina(String posizione, int n_auto_limite, int velocita_limite) throws MalformedURLException, RemoteException, NotBoundException;
}
