package shared;

import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IntCentralina extends Remote{
	public void salvaDatiStradali(String id_centralina, String inizio, String fine, int velocita_media, int n_veicoli) throws RemoteException;
}
