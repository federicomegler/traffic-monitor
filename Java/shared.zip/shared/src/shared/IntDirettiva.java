package shared;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface IntDirettiva extends Remote{
	public void nuovaCentralina(String posizione, String id_centralina, int numero_veicoli_limite,int limite_velocita) throws RemoteException;
	public void eliminaCentralina(String id_centralina) throws RemoteException;
}
