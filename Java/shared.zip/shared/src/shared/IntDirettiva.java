package shared;

import java.rmi.Remote;
import java.rmi.RemoteException;


public interface IntDirettiva extends Remote{
	public void nuovaCentralina(String nome_via, String inizio, String fine, int id_centralina, int numero_veicoli_limite,int limite_velocita) throws RemoteException;
	public void eliminaCentralina(String id_centralina) throws RemoteException;
}
