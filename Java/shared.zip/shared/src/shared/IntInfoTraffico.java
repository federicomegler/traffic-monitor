package shared;

import java.rmi.Remote;

public interface IntInfoTraffico extends Remote{

}
