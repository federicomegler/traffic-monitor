package shared;

public interface IntInfoTraffico {

}
