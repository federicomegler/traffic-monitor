package shared;
import java.io.IOException;
import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.Set;

public interface IntMappa extends Remote{

	public Set<String> generaLinee() throws RemoteException, IOException;	
}
