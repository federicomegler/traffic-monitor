package shared;
import java.rmi.Remote;
import java.rmi.RemoteException;

public interface IntSegnalazioni extends Remote{
	public boolean inviaSegnalazione(char tipo_traffico, String posizione) throws RemoteException;
}
